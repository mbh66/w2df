---
source: CATHSSETA discretionary grants
pool: State
decider: CATHSSETA
pays_for: Learnerships, bursaries, skills programmes, internships
eligible_applicant: Levy payers, non-levy employers in its sectors, universities, TVET colleges, government, accredited providers
typical_size: Unit costs in separate guidelines, not found
cycle_deadline: 2025/26 window closed 31 January 2025
preconditions: 60% of funds to levy payers
campus_fit: Medium for tourism courses once accredited
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Guidelines](https://cathsseta.org.za/storage/announcements/1752074586_DG%20application%20guidelines%20.pdf).
