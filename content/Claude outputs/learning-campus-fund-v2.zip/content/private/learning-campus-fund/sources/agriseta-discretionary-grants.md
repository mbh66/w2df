---
source: AgriSETA discretionary grants
pool: State
decider: AgriSETA
pays_for: Learnerships, skills programmes, bursaries, internships, artisans
eligible_applicant: Employers, NGOs, NPOs, cooperatives, TVET colleges, land reform beneficiaries; no individuals
typical_size: Learnership R30,000 plus R24,000 stipend; skills programmes R200 a credit to 60 credits; bursaries R70,800
cycle_deadline: 1 August to 15 September 2026, for 2027/28
preconditions: Central Supplier Database; accredited provider
campus_fit: High for farming and conservation courses
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Advert](https://www.agriseta.co.za/wp-content/uploads/2026/08/0.1.-Advert-for-DG-Window-2027-2028-final-4.pdf).
