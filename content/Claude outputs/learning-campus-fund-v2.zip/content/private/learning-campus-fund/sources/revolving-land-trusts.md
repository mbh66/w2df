---
source: Revolving land trusts
pool: D
decider: A land trust
pays_for: Buying land, protecting it by title condition, reselling it
eligible_applicant: Trust with capital
typical_size: No South African example with figures found
cycle_deadline: Not applicable
preconditions: Land for sale
campus_fit: Uncertain on Farm 39, which cannot be bought while the Minister holds it
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

A BIOFIN 2018 option [MS].
