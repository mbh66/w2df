---
source: Kwaxala
pool: D
decider: Kwaxala
pays_for: Living Forest Shares paid from carbon and other services
eligible_applicant: Partner holding the land or its rights
typical_size: Not found
cycle_deadline: Not found
preconditions: Land or rights to partner on
campus_fit: Uncertain; has offered to work with the valley on water rights [MS]
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

See the W2DF Kwaxala page.
