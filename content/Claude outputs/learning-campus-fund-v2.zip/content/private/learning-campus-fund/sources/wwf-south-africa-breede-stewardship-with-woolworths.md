---
source: WWF South Africa Breede stewardship with Woolworths
pool: D
decider: WWF South Africa
pays_for: Water stewardship with farmers and towns; clearing
eligible_applicant: Farmer and catchment partners
typical_size: Not found
cycle_deadline: Not found
preconditions: Partner farms
campus_fit: Medium; WWF started the Riviersonderend clearing project in 2013
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Reports 200 million litres a year returned to the catchment [MS].
