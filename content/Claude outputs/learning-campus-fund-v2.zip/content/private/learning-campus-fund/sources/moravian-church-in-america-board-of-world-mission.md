---
source: Moravian Church in America Board of World Mission
pool: E
decider: Board of World Mission
pays_for: Needs and ministries identified by partners
eligible_applicant: Partner provinces
typical_size: Nearly $100,000 over the last few years
cycle_deadline: Not found
preconditions: Partner province; no South African partner listed
campus_fit: Small
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Mission grants](https://www.moravian.org/mission/mission-grants/).
