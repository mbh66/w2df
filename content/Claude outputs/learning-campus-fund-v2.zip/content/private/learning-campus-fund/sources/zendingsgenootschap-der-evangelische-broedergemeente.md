---
source: Zendingsgenootschap der Evangelische Broedergemeente
pool: E
decider: Society board (Zeist, Netherlands)
pays_for: Mission partnerships
eligible_applicant: Partner churches
typical_size: Revenue €0.6m to €1.1m a year (2019-24)
cycle_deadline: Not found
preconditions: Not found
campus_fit: Small; South African work not confirmed [TBV]
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Founded 1793 [MS].
