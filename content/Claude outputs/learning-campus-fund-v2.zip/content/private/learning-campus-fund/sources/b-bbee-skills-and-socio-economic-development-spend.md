---
source: B-BBEE skills and socio-economic development spend
pool: State
decider: Companies
pays_for: Skills and socio-economic development
eligible_applicant: Beneficiary entities
typical_size: Not found
cycle_deadline: Company financial years
preconditions: B-BBEE scorecard
campus_fit: Medium
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Bonnievale's Trust is a B-BBEE ownership vehicle earning dividends or turnover payments from small companies [MS].
