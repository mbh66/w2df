---
source: Global Environment Facility
pool: D
decider: GEF; DFFE as focal point
pays_for: Biodiversity, climate and land degradation projects
eligible_applicant: National project through a GEF agency
typical_size: 'GEF-8 South Africa: US$35.69m biodiversity, US$7.36m climate, US$6.05m land degradation (US$49.10m)'
cycle_deadline: GEF-8 2022-26; GEF-9 from 2026, US$3.9bn pledged April 2026; SA allocation not found
preconditions: Endorsement by the focal point
campus_fit: Low directly; possible inside a national stewardship project
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[GEF-8 STAR allocations](https://www.thegef.org/sites/default/files/documents/2022-07/EN_GEF_C.63_Inf.05_Initial%20GEF-8%20STAR%20Country%20Allocations__0.pdf).
