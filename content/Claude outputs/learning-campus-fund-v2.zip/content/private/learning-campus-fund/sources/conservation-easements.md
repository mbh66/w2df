---
source: Conservation easements
pool: D
decider: Landowner and conservation trust
pays_for: Permanent protection with management support
eligible_applicant: Willing landowner
typical_size: 'ORCT: six easements, nearly 1,500 ha by August 2019'
cycle_deadline: Not applicable
preconditions: Willing landowner; servitude
campus_fit: Possible on Erf 595 or private land; on Farm 39 only after transfer
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[ORCT, 2019](https://overbergrenosterveld.org.za/another-easement-signed).
