---
source: Freunde der Erziehungskunst International Relief Fund
pool: E
decider: Freunde der Erziehungskunst Rudolf Steiners
pays_for: School fees and teacher training at free schools worldwide
eligible_applicant: Free (Waldorf) schools
typical_size: Not found
cycle_deadline: Urgent requests
preconditions: Free school
campus_fit: Teacher training for block and project teaching
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Passes 100% of donations to schools [MS].
