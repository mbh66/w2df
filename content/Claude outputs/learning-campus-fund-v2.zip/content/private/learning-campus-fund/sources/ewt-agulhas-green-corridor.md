---
source: EWT Agulhas Green Corridor
pool: D
decider: Endangered Wildlife Trust
pays_for: Not found under this name
eligible_applicant: Not found
typical_size: Not found
cycle_deadline: Not found
preconditions: Not found
campus_fit: Unknown
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

No programme of this name was found [TBV]. Ask the EWT.
