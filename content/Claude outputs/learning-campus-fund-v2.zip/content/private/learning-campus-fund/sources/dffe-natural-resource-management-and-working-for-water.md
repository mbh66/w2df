---
source: DFFE Natural Resource Management and Working for Water
pool: D
decider: DFFE
pays_for: Invasive clearing; jobs
eligible_applicant: Registered implementer
typical_size: National budget fell from R1.7bn (2020/21) to R377m (2024)
cycle_deadline: Annual allocations
preconditions: Implementer registration; DFFE project allocation
campus_fit: Medium; programme shrinking
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Contract costs 1997/98 to 2005/06 at 75% to 100% cover: Acacia R3,301/ha, Eucalyptus R3,201/ha, Pinus R1,491/ha, excluding overheads [MS] ([Marais & Wannenburgh, 2008](https://www.dws.gov.za/wfw/docs/Marais&Wannenburgh,2008.pdf)). Budget figures: [Daily Maverick, 20 May 2025](https://www.dailymaverick.co.za/article/2025-05-20-sa-government-kills-funding-for-best-weapon-against-invasive-trees).
