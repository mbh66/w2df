---
source: Herrnhuter Missionshilfe
pool: E
decider: Herrnhuter Missionshilfe (Germany)
pays_for: Projects through EMS, for example in education and youth
eligible_applicant: Partner churches
typical_size: Not found
cycle_deadline: Not found
preconditions: Partnership through EMS
campus_fit: Legitimacy and story; small sums
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

No South African project or amount named in its 2025 South Africa issue [MS].
