---
source: Green Climate Fund
pool: D
decider: GCF; accredited entities such as DBSA
pays_for: Climate finance
eligible_applicant: Accredited entity
typical_size: 'DBSA Climate Finance Facility: US$55.61m GCF, about US$171m total (2018)'
cycle_deadline: Board approvals
preconditions: Accredited entity; climate case
campus_fit: Low; no climate-finance project
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[FP098](https://www.greenclimate.fund/portfolio/projects/fp098).
