---
source: Draft NBSAP 2026 to 2035
pool: D
decider: DFFE
pays_for: Not a fund; national targets on money and skills
eligible_applicant: Not applicable
typical_size: Not applicable
cycle_deadline: Gazette 55141, GN 7773, August 2026; 30 days for comment
preconditions: Not applicable
campus_fit: Frames the case; the joined target on money and skills matches the training centre
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Gazette](https://www.gov.za/sites/default/files/gcis_document/202608/55141gon7773.pdf).
