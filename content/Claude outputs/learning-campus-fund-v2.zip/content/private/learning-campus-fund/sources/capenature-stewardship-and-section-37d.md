---
source: CapeNature stewardship and section 37D
pool: D
decider: CapeNature; SARS
pays_for: Tax deduction for the landowner; property rates exclusion
eligible_applicant: Landowner of a declared nature reserve or national park
typical_size: 4% of land value a year over 25 years, unlocked in year 1
cycle_deadline: On declaration
preconditions: Declaration under NEMPAA; title deed endorsed for at least 99 years
campus_fit: Depends on the Farm 39 transfer and on the landowner paying tax
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Confirmed from CapeNature's 2026 landowner fact sheet [MS] and UNDP (2024) [MS], together [IC]. Section 37C covers biodiversity management agreements separately. [CapeNature fact sheet](https://www.capenature.co.za/uploads/files/Landowners-Fact-Sheet-on-Fiscal-Benefits-for-Nature-Reserves-2026_English.pdf).
