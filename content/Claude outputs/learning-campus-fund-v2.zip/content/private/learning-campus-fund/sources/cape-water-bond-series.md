---
source: Cape Water bond series
pool: D
decider: RMB with outcome funders; Conservation Alpha verifies
pays_for: Investors' bonus tied to verified hectares cleared; TNC receives R150m over five years for clearing
eligible_applicant: Implementer in a priority catchment (TNC in the first bond)
typical_size: R2.5bn bond; R150m to clearing over five years
cycle_deadline: First bond April 2026; series intended
preconditions: Priority catchment; verified baseline; independent verifier
campus_fit: Low for the first bond (valley downstream of Theewaterskloof Dam); possible for a later bond covering the Boland SWSA's lower catchments [TBV]
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

The valley's rivers join the Riviersonderend below Theewaterskloof Dam, outside the catchments the first bond pays for [IC]. Sources: [RMB](https://rmb.co.za/news/rmb-launches-africas-first-naturelinked-outcomesbased-bond); [TNC](https://www.nature.org/en-us/newsroom/cape-water-performance-based-bond-launched/).
