---
source: BIOFIN Biodiversity Finance Plan (2018)
pool: D
decider: DFFE, SANBI, UNDP
pays_for: Not a fund; sixteen finance options
eligible_applicant: Not applicable
typical_size: R63bn needed over ten years; R11.54bn government spend in 2016
cycle_deadline: 2018 plan
preconditions: Not applicable
campus_fit: Frames the case to DFFE
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Options include revolving land trusts and better-funded stewardship [MS]. [Plan](https://www.biofin.org/sites/default/files/content/knowledge_products/BIOFIN%20SA_BFP_Min%20Approved.pdf).
