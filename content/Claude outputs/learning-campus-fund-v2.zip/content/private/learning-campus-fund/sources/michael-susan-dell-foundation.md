---
source: Michael & Susan Dell Foundation
pool: E
decider: The Foundation
pays_for: Bonnievale 418 and its strategic planning
eligible_applicant: Not found
typical_size: Not found
cycle_deadline: Not found
preconditions: Not found
campus_fit: The nearest precedent for the campus
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Named a main funder of Bonnievale 418 by IPASA (2023) [MS].
