---
source: Table Mountain Fund
pool: D
decider: Trustees (associated trust of WWF South Africa)
pays_for: Conservation in the Cape Floristic Region
eligible_applicant: Projects in the Cape Floristic Region
typical_size: R116m to 380+ projects since 1998; small grants up to R36,250
cycle_deadline: Programme calls
preconditions: Project in the Region
campus_fit: Medium for small grants and easements
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Funded the Keykas easement in the Overberg in 2019 [MS]. Donations may qualify for Section 18A [MS].
