---
source: Jobs Fund
pool: State
decider: National Treasury
pays_for: Job creation in the green and informal economy (13th round)
eligible_applicant: Sector intermediaries with a track record
typical_size: Minimum R5m; matched funding
cycle_deadline: 13th round closed 30 June 2026
preconditions: Matched funding; results within three years
campus_fit: Medium for the landscape window once an intermediary exists
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Treasury, 22 May 2026](https://www.gov.za/news/media-statements/national-treasury-jobs-fund-launching-13th-funding-round-22-may-2026).
