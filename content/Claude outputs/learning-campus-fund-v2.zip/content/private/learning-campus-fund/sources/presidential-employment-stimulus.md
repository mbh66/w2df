---
source: Presidential Employment Stimulus
pool: State
decider: The Presidency and departments
pays_for: Public employment
eligible_applicant: Implementing departments and partners
typical_size: R3.3bn in 2026/27, down from R8.3bn
cycle_deadline: Annual budget
preconditions: Not found
campus_fit: Low; being cut
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Business Day, 2 June 2026](https://www.businessday.co.za/opinion/2026-06-02-duma-gqubule-job-programme-cut-as-treasury-seeks-budget-surplus/).
