---
source: WCED collaboration schools
pool: State
decider: Western Cape Education Department
pays_for: School buildings (share) and salaries
eligible_applicant: Non-profit school partner
typical_size: 'Bonnievale: R54m of about R154m in buildings; more than 90% of salaries'
cycle_deadline: Not found
preconditions: Public school status; partner holds half the governing body seats
campus_fit: School of skills and the day school
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

11 collaboration schools in 2023 [MS] ([IPASA](https://ipa-sa.org.za/wp-content/uploads/2023/11/IPASA-Collaboration-Case-Study_Jakes-Gerwel-Technical-School-and-Bonnievale-418_November-2023.pdf)).
