---
source: London Association in Aid of Moravian Missions
pool: E
decider: Trustees (UK charity 247127)
pays_for: Moravian missionary activities
eligible_applicant: Moravian bodies
typical_size: Income £91,630 (year to April 2025)
cycle_deadline: Not found
preconditions: Not found
campus_fit: Small
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[OpenCharities](https://opencharities.uk/ew/247127).
