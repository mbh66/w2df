---
source: Evangelische Mission in Solidarität
pool: E
decider: EMS (Germany)
pays_for: 'Youth ministry of the Moravian Church in South Africa: careers, interviews, business start-up, counselling'
eligible_applicant: Member churches
typical_size: Not found
cycle_deadline: 2025-26 project sheet
preconditions: Through the Moravian Church in South Africa
campus_fit: Medium for youth pathways
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

[Project sheet](https://ems-online.org/fileadmin/EMS/Projekte/2025_2026_Projektblaetter/Projekt_25_26_Suedafrika_Zukunftsperspektiven_en.pdf).
