---
source: National Skills Fund
pool: State
decider: Department of Higher Education and Training
pays_for: Skills projects through providers and partners
eligible_applicant: Providers, TVET colleges, partners
typical_size: TVET projects of R45m to R51m over three years
cycle_deadline: Not found
preconditions: Partner with capacity
campus_fit: Medium through a TVET partner
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

2025/26: R112m to TVET infrastructure; R52.7m to system capacity [MS].
