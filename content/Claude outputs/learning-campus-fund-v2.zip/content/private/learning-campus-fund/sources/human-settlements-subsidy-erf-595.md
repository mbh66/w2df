---
source: Human Settlements subsidy, Erf 595
pool: State
decider: Province and municipality
pays_for: Erf 595 housing
eligible_applicant: Municipality
typical_size: R10m Human Settlement Grant 2025/26, removed February 2026 after R1.2m spent
cycle_deadline: Authorisation valid ten years from 10 July 2025
preconditions: Approved project; beneficiary list
campus_fit: High for Erf 595
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

333 homes authorised [IC].
