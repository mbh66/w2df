---
source: Greater Cape Town Water Fund
pool: D
decider: Steering committee; TNC leads
pays_for: Clearing in seven priority sub-catchments
eligible_applicant: TNC-led partners
typical_size: R372m PV over 30 years (2018 prices); 41,000 of 54,300 ha cleared by April 2026
cycle_deadline: Ongoing
preconditions: Sub-catchment feeds a Western Cape Water Supply System dam
campus_fit: Low; Upper Riviersonderend, above the dam, is priority 2
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Business Case (2019): R40,000 per densely invaded hectare at most; R372m ÷ 10,488 condensed ha ≈ R35,470 per condensed ha over 30 years (Inference from published totals). [Business Case](https://www.nature.org/content/dam/tnc/nature/en/documents/GCTWF-Business-Case-April-2019.pdf).
