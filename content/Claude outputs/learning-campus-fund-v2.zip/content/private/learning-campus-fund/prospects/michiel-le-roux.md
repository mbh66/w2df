---
name: Michiel le Roux
pool: A
giving_vehicle: None named; gave shares directly
section_18a: unknown
giving_fields:
- COVID-19 relief
- party-political donations
largest_gift_amount: About R100m in Capitec shares to three COVID-19 relief funds
largest_gift_year: '2020'
largest_gift_source: The Citizen, 29 April 2020
link_to_campus: None found
link_to_valley: None found
route_in: None identified
controversy_screen: Large declared donor to the Democratic Alliance (2025-26); Viceroy's 2018 report on Capitec, after which the Reserve Bank said Capitec was solvent
gift_range_low: 10
gift_range_high: 50
fit_score: 2
evidence_tags:
- IC
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: no education or rural gift found. A party-political donor at the top of the ask needs care for a ward body that serves voters of every party (Inference). Net worth $3.8bn, Forbes Africa 2026 [IC].
