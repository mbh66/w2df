---
name: Oppenheimer Memorial Trust
pool: C
giving_vehicle: Oppenheimer Memorial Trust
section_18a: unknown
giving_fields:
- scholarships
- grants to institutions
largest_gift_amount: R3.8m (Rhodes University, remote teaching)
largest_gift_year: ''
largest_gift_source: Rhodes University news
link_to_campus: Bursaries; training centre
link_to_valley: None found
route_in: None identified; IPASA
controversy_screen: None found
gift_range_low: 10
gift_range_high: 40
fit_score: 3
evidence_tags:
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: youth and education fit, with a R1bn endowment added in 2012 [MS], but no rural or Western Cape place-based grant found.
