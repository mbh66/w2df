---
name: Motsepe Foundation
pool: C
giving_vehicle: Motsepe Foundation
section_18a: unknown
giving_fields:
- bursaries
- schools
- community development
largest_gift_amount: R1bn for students from poor backgrounds
largest_gift_year: '2020'
largest_gift_source: City Press, 28 March 2020 (search listing only)
link_to_campus: Bursaries
link_to_valley: None found
route_in: None identified
controversy_screen: None found
gift_range_low: 10
gift_range_high: 40
fit_score: 3
evidence_tags:
- IC
- TBV
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: joined the Giving Pledge in 2013 [IC] and gives at scale, but no rural Western Cape link or route in was found.
