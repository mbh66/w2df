---
name: Agricultural families (Dommisse list)
pool: A
giving_vehicle: Not identified
section_18a: unknown
giving_fields: []
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: 'Possible: training centre and hiring'
link_to_valley: None found
route_in: None identified
controversy_screen: Not screened
gift_range_low: null
gift_range_high: null
fit_score: 1
evidence_tags:
- TBV
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

ZZ2, Dutoit Group, Karsten, Schoeman Boerdery, Senekal, Serfontein, Greyling. Lower rank: giving unknown, and Dommisse's *Fortunes* could not be reached.
