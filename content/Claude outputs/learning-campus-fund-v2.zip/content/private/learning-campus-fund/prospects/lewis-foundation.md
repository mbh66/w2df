---
name: Lewis Foundation
pool: C
giving_vehicle: Lewis Foundation (trust, 1994)
section_18a: unknown
giving_fields:
- conservation skills
- nature-based solutions
- wildlife welfare
largest_gift_amount: Not public (bond outcome funding)
largest_gift_year: '2026'
largest_gift_source: RMB, 1 April 2026
link_to_campus: Training centre and landscape window together
link_to_valley: Indirect, through the Cape Water bond
route_in: Cape Water bond outcome funders
controversy_screen: None found
gift_range_low: 5
gift_range_high: 20
fit_score: 3
evidence_tags:
- IC
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank only for scale: since 2008 it has focused on training people for conservation work [MS], the closest match to the training centre of any funder found. No gift size published.
