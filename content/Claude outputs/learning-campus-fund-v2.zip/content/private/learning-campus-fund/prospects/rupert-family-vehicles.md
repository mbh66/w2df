---
name: Rupert family vehicles
pool: A
giving_vehicle: Rupert Education Foundation; Johann & Gaynor Rupert Foundation; Rupert Nature Foundation; Rupert Art Foundation
section_18a: unknown
giving_fields:
- schools in poor communities
- bursaries
- heritage
- conservation
- small business relief
largest_gift_amount: R1bn (Sukuma, grants and loans, with Remgro); R20m in a related field (Wupperthal)
largest_gift_year: 2020; 2019 to 2022
largest_gift_source: BusinessTech, 13 April 2020; Tourism Update
link_to_campus: Rupert Education Foundation is a main funder of Bonnievale 418; Remgro and the Rupert Nature Foundation fund the Cape Water bond
link_to_valley: Moravian heritage through Wupperthal
route_in: Remgro (Stephan May); Hanneli Rupert-Koegelenberg
controversy_screen: None found on the family's own conduct; Johann Rupert was the main target of the Bell Pottinger 'white monopoly capital' campaign (2016-17)
gift_range_low: 40
gift_range_high: 150
fit_score: 5
evidence_tags:
- IC
- MS
- TBV
full_profile: true
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

## Profile

- **Vehicles.** Rupert Education Foundation, Johann & Gaynor Rupert Foundation, Rupert Nature Foundation, Rupert Art Foundation, and the "Rupert Foundation" named in Wupperthal reports [IC]. Section 18A status is not published for any of them.
- **What they fund.** The Rupert Education Foundation supports "schools in poor, disadvantaged communities" in the Western Cape, Eastern Cape and Free State, as quoted by MiDO Foundation [MS]. It funds the Franschhoek and Jacobsdal Schools Projects and a bursary programme [MS]. It is one of four main funders of Bonnievale 418 [MS] ([IPASA, 2023](https://ipa-sa.org.za/wp-content/uploads/2023/11/IPASA-Collaboration-Case-Study_Jakes-Gerwel-Technical-School-and-Bonnievale-418_November-2023.pdf)).
- **Published gifts.** About R20m to rebuild Wupperthal after the 2018 fire [IC]. R1bn through the Sukuma Relief Programme in 2020, administered by Business Partners for the family and Remgro, as R25,000 grants and loans of R250,000 to R1m [IC] ([BusinessTech](https://businesstech.co.za/news/business/389231/r1-billion-rupert-fund-to-pay-out-from-tuesday/)).
- **Conservation.** First grant of R1.2m to Peace Parks in 1997 [TBV]; outcome funder of the Cape Water bond, April 2026 [IC].
- **Route in.** Remgro and Hanneli Rupert-Koegelenberg.

## Gift range (Inference)

R40m to R150m over ten years: two to seven and a half times the Wupperthal gift, the largest in a related field. Sukuma shows capacity, but it was relief of a different kind. The first run's R150m to R400m is withdrawn.
