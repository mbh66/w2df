---
name: FirstRand founders (FirstRand Foundation)
pool: A
giving_vehicle: FirstRand Foundation (corporate)
section_18a: unknown
giving_fields:
- water bond outcome funding
largest_gift_amount: R50m
largest_gift_year: '2026'
largest_gift_source: ATTA / RMB, April 2026
link_to_campus: Landscape window
link_to_valley: None; the bond pays upstream of the valley
route_in: Cape Water bond
controversy_screen: None found
gift_range_low: 10
gift_range_high: 50
fit_score: 3
evidence_tags:
- IC
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: its largest published gift went to the bond, which does not reach the valley. GT Ferreira, Laurie Dippenaar and Paul Harris were not screened individually.
