---
name: Mouton family (Jannie Mouton Stigting)
pool: A
giving_vehicle: Jannie Mouton Stigting (Jannie Mouton Foundation), a public benefit organisation
section_18a: unknown
giving_fields:
- higher education
- school education
- bursaries
largest_gift_amount: R7.2bn (Curro taken private as a non-profit); R50m to a body it does not control (Stellenbosch University)
largest_gift_year: 2025-26; 2016
largest_gift_source: Daily Maverick, 27 August 2025; The Citizen, December 2025; TimesLive, 8 June 2016
link_to_campus: Curro, now a non-profit PBO with 189 schools, could be asked to run the boarding school as a tenant
link_to_valley: None found
route_in: None identified (PSG, Capitec and Stellenbosch University are its networks)
controversy_screen: None found
gift_range_low: 25
gift_range_high: 150
fit_score: 4
evidence_tags:
- IC
- MS
full_profile: true
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

## Profile

- **Vehicle.** Set up in 2017 with 10.5 million PSG shares [MS]. Described as a public benefit organisation [MS]. Section 18A status not published.
- **Curro.** The Stigting offered R7.2bn for all Curro shares in August 2025, paid mostly in Capitec and PSG Financial Services shares [IC]. The deal became unconditional in December 2025, and Curro left the JSE in January 2026 to become a public benefit organisation with no shareholders [IC]. All surpluses go to new schools, bursaries and education projects, including in lower-income areas [MS] ([Daily Maverick](https://www.dailymaverick.co.za/article/2025-08-27-jannie-mouton-foundations-r7-2bn-curro-bid-could-redefine-private-education); [The Citizen](https://www.citizen.co.za/business/curro-mouton-deal-becomes-unconditional-ahead-of-jse-delisting)).
- **Stellenbosch University.** R50m in 2016 for a Centre for Teaching and Learning [MS] ([TimesLive](https://www.timeslive.co.za/news/south-africa/2016-06-08-sa-billionaire-donates-r50-million-to-revitalise-education-at-stellenbosch-university/)).
- **Net worth.** $2.7bn, Forbes Africa 2026 [IC].
- **The question.** Could Curro run the boarding school as a tenant on land it does not own, with at most one seat on the ward trust?

## Gift range (Inference)

R25m to R150m. The R50m university gift is the largest to a body the family does not control; the Curro gift went to a vehicle the Stigting owns.
