---
name: Koos Bekker
pool: A
giving_vehicle: Not identified
section_18a: unknown
giving_fields: []
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: None found
link_to_valley: None found
route_in: None identified
controversy_screen: Naspers, the company he chairs, apologised in 2015 for its role under apartheid
gift_range_low: 5
gift_range_high: 30
fit_score: 1
evidence_tags:
- IC
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: no youth or rural gift found. Net worth $3.6bn, Forbes Africa 2026 [IC].
