---
name: Ackerman Pick n Pay Foundation
pool: C
giving_vehicle: Ackerman Pick n Pay Foundation
section_18a: unknown
giving_fields:
- youth enterprise
- school support
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: Training centre enterprise support
link_to_valley: None found
route_in: None identified
controversy_screen: None found
gift_range_low: 1
gift_range_high: 5
fit_score: 1
evidence_tags:
- TBV
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: no grant sizes or rural work found.
