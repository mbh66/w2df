---
name: Douw Steyn Family Trust
pool: A
giving_vehicle: Douw Steyn Family Trust
section_18a: unknown
giving_fields:
- COVID-19 relief
largest_gift_amount: R320m pledge (the July 2026 list says R370m)
largest_gift_year: '2020'
largest_gift_source: Wikipedia, citing The South African, 15 April 2020
link_to_campus: None found
link_to_valley: None found
route_in: None identified
controversy_screen: None found that concerns the trust's giving
gift_range_low: 10
gift_range_high: 50
fit_score: 2
evidence_tags:
- TBV
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: Douw Steyn died in February 2025 [IC]; no education link found. Latest net worth found is £2.05bn, Sunday Times Rich List 2021 [TBV].
