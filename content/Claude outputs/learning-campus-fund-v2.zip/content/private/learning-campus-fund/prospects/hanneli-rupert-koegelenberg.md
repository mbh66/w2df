---
name: Hanneli Rupert-Koegelenberg
pool: B
giving_vehicle: Five family foundations (not named publicly); Inceba Trust; Hanneli Rupert Getuienis Trust; In Harmonie NPC
section_18a: unknown
giving_fields:
- education
- social development
- classical music
- art
- nature conservation
- historic buildings
- reconciliation
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: Heritage, reconciliation and education
link_to_valley: Moravian Church; 2022 Pilgrimage of Grace at Genadendal
route_in: Open relationship
controversy_screen: None found
gift_range_low: null
gift_range_high: null
fit_score: 5
evidence_tags:
- MS
full_profile: true
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

## Profile

- **Her own account.** "As a trustee of five family foundations, she is actively involved in supporting and furthering fields that are also close to her heart" [MS] ([profile](https://www.hannelirupert.net/profile/)). She owns La Motte and co-owns Leopard's Leap [MS].
- **Roles on record.** Trustee of the Anton Rupert Trust and the Rupert Art Foundation (2006) [MS]; trustee of the Helgaard Steyn Trust [MS]; founder and trustee of the Inceba Trust (2017) [MS]; founder of the Hanneli Rupert Getuienis Trust and In Harmonie NPC [MS]. No source says which five foundations she counts.
- **Not to be confused with** Hanneli Rupert, Johann Rupert's daughter.

## Gift range (Inference)

Within the Rupert family range. No separate figure is set.
