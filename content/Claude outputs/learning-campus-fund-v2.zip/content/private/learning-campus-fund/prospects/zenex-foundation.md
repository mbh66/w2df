---
name: Zenex Foundation
pool: C
giving_vehicle: Zenex Foundation
section_18a: unknown
giving_fields:
- language education
- mathematics education
largest_gift_amount: Over R1.5bn invested since 1995 (a running total)
largest_gift_year: 1995-2025
largest_gift_source: Trialogue, 2025
link_to_campus: Teacher training for project-based learning
link_to_valley: None found
route_in: IPASA
controversy_screen: None found
gift_range_low: 2
gift_range_high: 10
fit_score: 2
evidence_tags:
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: works on systemic change in early-grade language and maths with government [MS], which is narrow for the campus.
