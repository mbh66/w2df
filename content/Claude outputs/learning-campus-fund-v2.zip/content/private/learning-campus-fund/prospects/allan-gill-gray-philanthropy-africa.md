---
name: Allan & Gill Gray Philanthropy Africa
pool: C
giving_vehicle: Allan & Gill Gray Philanthropy Africa
section_18a: unknown
giving_fields:
- education
- literacy data
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: Youth and education
link_to_valley: None found
route_in: None identified
controversy_screen: None found
gift_range_low: 10
gift_range_high: 40
fit_score: 3
evidence_tags:
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: an education funder that co-funds with the Gates Foundation [MS], with no rural or place-based Western Cape work found.
