---
name: Paul van Zuydam
pool: A
giving_vehicle: Not identified
section_18a: unknown
giving_fields: []
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: None found
link_to_valley: None found
route_in: None identified
controversy_screen: None found
gift_range_low: 0
gift_range_high: 20
fit_score: 1
evidence_tags:
- IC
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: Swiss-resident; no giving record found. Net worth $1.7bn, Forbes, reported April 2026 [IC].
