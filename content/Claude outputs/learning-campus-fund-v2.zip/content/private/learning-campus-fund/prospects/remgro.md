---
name: Remgro
pool: B
giving_vehicle: Remgro CSI
section_18a: 'no'
giving_fields:
- water stewardship
- Cape Water bond outcome funding
largest_gift_amount: Not public (bond outcome funding)
largest_gift_year: '2026'
largest_gift_source: RMB, 1 April 2026
link_to_campus: Landscape window
link_to_valley: 'Indirect: the bond pays for catchments above Theewaterskloof Dam, upstream of the valley'
route_in: Places Conversation (Stephan May)
controversy_screen: None found
gift_range_low: 10
gift_range_high: 40
fit_score: 4
evidence_tags:
- IC
- MS
full_profile: true
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

## Profile

- Outcome funder of the Cape Water bond with the Rupert Nature Foundation and the Lewis Foundation [IC]. On the Greater Cape Town Water Fund's steering committee from 2018 [MS].
- Rupert Beleggings holds all unlisted B shares, about 43% of the votes [MS]. Treat Remgro and the Rupert vehicles as one relationship.
- CSI totals not found [TBV]. Section 18A: not applicable to a listed company.

## Gift range (Inference)

R10m to R40m. No published CSI figure supports a higher range.
