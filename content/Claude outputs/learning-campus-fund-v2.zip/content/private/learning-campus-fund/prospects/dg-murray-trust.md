---
name: DG Murray Trust
pool: B
giving_vehicle: DG Murray Trust
section_18a: unknown
giving_fields:
- place-based development
- early learning
- youth pathways
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: Advice and possibly co-funding for the 2027 feasibility study
link_to_valley: None
route_in: Places Conversation (Sinazo Nkwelo)
controversy_screen: None found
gift_range_low: 2
gift_range_high: 10
fit_score: 2
evidence_tags:
- MS
- TBV
full_profile: true
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

## Profile

- Place-based portfolio in "several municipalities in the Northern Cape, Free State, Eastern Cape and KwaZulu-Natal" [MS]. The Western Cape is not named.
- No evidence found that DGMT funds buildings or endowments [TBV]. No grant size found [TBV].
- Fit lowered from 4 to 2 in version 2. It rises if DGMT says it would co-fund outside its named provinces.
