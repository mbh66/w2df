---
name: Christo Wiese / JD Wiese
pool: A
giving_vehicle: Titan Premier Investments (investment vehicle)
section_18a: unknown
giving_fields: []
largest_gift_amount: Not found
largest_gift_year: ''
largest_gift_source: ''
link_to_campus: 'Question: hiring by Shoprite or Pepkor'
link_to_valley: None found
route_in: None identified
controversy_screen: Chairman of Steinhoff at its collapse in December 2017; sued Steinhoff and settled
gift_range_low: 5
gift_range_high: 30
fit_score: 1
evidence_tags:
- IC
- MS
full_profile: false
draft: true
---

> [!warning] Private working note
> Moderators only. Names living people and published wealth. Not for the public site. Source: *Learning Campus Fund strategy, version 2* (workbench).

> [!info] Tags
> [IC] two or more independent sources or an official record. [MS] one party's own documents or statements, or the Forum's own research. [TBV] plausible and unconfirmed. Gift ranges are inferences from published giving.

Lower rank: no published gift found; reputational screen needed. Net worth $1.9bn, Forbes Africa 2026 [IC].
