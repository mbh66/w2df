"""Cost model and bridge for the Learning Campus Fund v2. All figures R million, 2026 rands unless stated."""
r = lambda x: round(x, 1)
out = []
p = out.append

# ---------- B1 Campus ----------
day_m2, board_m2 = 5400, 12300
day_lo, day_hi = 9944, 13560        # Setout 2026, Cape Town schools
brd_lo, brd_hi = 9800, 13500        # AECOM 2024/25 low-rise apartments, proxy
site_lo, site_hi = 80, 150
def campus(day_rate, brd_rate, site, premium=0.0):
    day = day_m2 * day_rate / 1e6
    brd = board_m2 * brd_rate / 1e6
    bld = day + brd
    prem = bld * premium
    fees = (bld + prem) * 0.25
    sub = bld + prem + fees + site
    vat = sub * 0.15
    return dict(day=day, brd=brd, bld=bld, prem=prem, fees=fees, site=site, sub=sub, vat=vat, tot=sub + vat)
c_lo = campus(day_lo, brd_lo, site_lo)
c_hi = campus(day_hi, brd_hi, site_hi)
c_mid = campus((day_lo + day_hi) / 2, (brd_lo + brd_hi) / 2, (site_lo + site_hi) / 2)
c_mid_eb = campus((day_lo + day_hi) / 2, (brd_lo + brd_hi) / 2, (site_lo + site_hi) / 2, premium=0.15)
c_mid_eb10 = campus((day_lo + day_hi) / 2, (brd_lo + brd_hi) / 2, (site_lo + site_hi) / 2, premium=0.10)
for k, c in [("low", c_lo), ("mid", c_mid), ("high", c_hi), ("mid+earthship15", c_mid_eb), ("mid+earthship10", c_mid_eb10)]:
    p(f"campus {k}: day {r(c['day'])} brd {r(c['brd'])} bld {r(c['bld'])} prem {r(c['prem'])} fees {r(c['fees'])} site {c['site']} sub {r(c['sub'])} vat {r(c['vat'])} tot {r(c['tot'])}")
eb_premium = c_mid_eb['tot'] - c_mid['tot']
eb_premium10 = c_mid_eb10['tot'] - c_mid['tot']
p(f"earthship premium 10%: {r(eb_premium10)}  15%: {r(eb_premium)}")
day_share = c_mid['day'] / c_mid['bld']
day_part = c_mid['tot'] * day_share
p(f"day-school share of building {r(day_share*100)}% ; day-school part of campus {r(day_part)}")
wced_lo, wced_hi = day_part * 0.35, day_part * 0.40
p(f"WCED share at 35%/40% of day-school part: {r(wced_lo)} / {r(wced_hi)}")

# ---------- B2 Endowment ----------
day_fee = 0.1516           # R m; Uplands College day fee 2026, lowest day fee on the page
board_fee = 0.270          # R m; floor for top-26 boarding schools (page)
board_fee_wc = 0.3233      # Bridge House, lowest WC boarding fee listed
boarders, feeday = 400, 50
levy = 0.075
def endow(places, train=9.0, blc=4.5, trust=3.0, bfee=board_fee):
    burs = places * day_fee
    gross = burs + train + blc + trust
    contrib = (boarders * bfee + feeday * day_fee) * levy
    net = gross - contrib
    return dict(burs=burs, gross=gross, contrib=contrib, net=net, endow=net / 0.04)
e_core = endow(150)
e_full = endow(190)
for k, e in [("core 150", e_core), ("full 190", e_full)]:
    p(f"endow {k}: burs {r(e['burs'])} gross {r(e['gross'])} contrib {r(e['contrib'])} net {r(e['net'])} endowment@4% {r(e['endow'])}")
e_wc = endow(150, bfee=board_fee_wc)
p(f"sensitivity: core with boarding fee R323,300: contrib {r(e_wc['contrib'])} net {r(e_wc['net'])} endowment {r(e_wc['endow'])}")
e_lo = endow(150, 6, 3, 2); e_hi = endow(190, 12, 6, 4)
p(f"endow range low (150, low running) {r(e_lo['endow'])}  high (190, high running) {r(e_hi['endow'])}")

# ---------- B3 Landscape ----------
gctwf_per_cond_ha_2018 = 372 / 10488 * 1e6   # rand per condensed ha, PV 2018 prices, 30 yrs
cpi = [1.041, 1.033, 1.045, 1.069, 1.060, 1.044, 1.032, 1.035]  # 2019..2026, assumption
f = 1.0
for x in cpi: f *= x
rate26 = gctwf_per_cond_ha_2018 * f / 1e6
p(f"GCTWF R/condensed ha 2018 {round(gctwf_per_cond_ha_2018)} ; CPI factor {round(f,3)} ; 2026 R m/ha {round(rate26,4)}")
valley = 11194
cond_lo, cond_hi = valley * 0.10, valley * 0.25
cond_mid = (cond_lo + cond_hi) / 2
clear_lo, clear_mid, clear_hi = cond_lo * rate26, cond_mid * rate26, cond_hi * rate26
p(f"condensed ha lo/mid/hi {round(cond_lo)}/{round(cond_mid)}/{round(cond_hi)} ; clearing {r(clear_lo)}/{r(clear_mid)}/{r(clear_hi)}")
other_lo = 10 + 10 + 3 + 10
other_hi = 30 + 25 + 10 + 40
other_mid = (other_lo + other_hi) / 2
land_lo, land_mid, land_hi = clear_lo + other_lo, clear_mid + other_mid, clear_hi + other_hi
p(f"landscape lo/mid/hi {r(land_lo)}/{r(land_mid)}/{r(land_hi)}")
p(f"cross-check: R150m / 13,300 remaining GCTWF ha = R{round(150e6/13300)} per ha (inference)")

# ---------- B4 Erf 595 ----------
units = 333
u_lo, u_hi = 0.128 + 0.080, 0.280 + 0.150
u_mid = (u_lo + u_hi) / 2
erf_lo, erf_mid, erf_hi = units * u_lo, units * u_mid, units * u_hi
p(f"Erf 595 unit lo/mid/hi {u_lo}/{u_mid}/{u_hi} ; totals {r(erf_lo)}/{r(erf_mid)}/{r(erf_hi)} ; gap mid->hi {r(erf_hi-erf_mid)}")

# ---------- B5 ----------
landproc = 30.0

# ---------- B6 Band ----------
core = dict(campus=c_mid['tot'], endow=e_core['endow'], landscape=land_mid, erf=erf_mid, landproc=landproc)
core_tot = sum(core.values())
adds = dict(earthship=eb_premium, bursary=e_full['endow'] - e_core['endow'], landscape_top=land_hi - land_mid, erf_gap=erf_hi - erf_mid)
adds_tot = sum(adds.values())
p("CORE " + " ".join(f"{k} {r(v)}" for k, v in core.items()) + f" TOTAL {r(core_tot)}")
p("ADDS " + " ".join(f"{k} {r(v)}" for k, v in adds.items()) + f" TOTAL {r(adds_tot)}")
p(f"TOP TOTAL {r(core_tot + adds_tot)}")

# state carve-outs
st_lo, st_hi = wced_lo + erf_mid, wced_hi + erf_mid
p(f"state may carry: WCED {r(wced_lo)}-{r(wced_hi)} + HS subsidy {r(erf_mid)} = {r(st_lo)}-{r(st_hi)}")
p(f"own raising at R1.5bn level: {r(core_tot - st_hi)} to {r(core_tot - st_lo)} (with state) ; {r(core_tot)} (without)")
top = core_tot + adds_tot
p(f"own raising at R1.8bn level: {r(top - st_hi)} to {r(top - st_lo)} (with state; Erf gap stays with fund) ; {r(top)} (without)")

# 2030 nominal
esc = 0.06
cap_core = core['campus'] + core['erf'] + core['landproc']
cap_top = cap_core + adds['earthship'] + adds['erf_gap']
def nominal(capital, total, years=4):
    return total + capital * ((1 + esc) ** years - 1)
p(f"2030 nominal (capital items escalated 6%/yr x4 = factor {round((1+esc)**4,4)}): core {r(nominal(cap_core, core_tot))} top {r(nominal(cap_top, top))}")
cpi_end = 0.045
p(f"2030 nominal, all items 4.5% CPI x4 (factor {round((1+cpi_end)**4,4)}): core {r(core_tot*(1+cpi_end)**4)} top {r(top*(1+cpi_end)**4)}")

# ---------- Bridge ----------
bridge = [
 ("Pool A lead: Rupert family vehicles", 40, 150),
 ("Pool A: Mouton family (Jannie Mouton Stigting)", 25, 150),
 ("Pool A others (le Roux, Steyn trust, FirstRand founders, others)", 50, 200),
 ("Pool B: DG Murray Trust (process only)", 2, 10),
 ("Pool B: Remgro CSI", 10, 40),
 ("Pool C: other SA family foundations", 50, 150),
 ("Pool D: DFFE NRM / Working for Water", 10, 40),
 ("Pool D: water bond series and GCTWF", 0, 60),
 ("Pool D: GEF, GCF, Table Mountain Fund, stewardship", 5, 30),
 ("State: WCED share of school buildings", round(wced_lo), round(wced_hi)),
 ("State: Human Settlements subsidy, Erf 595", round(erf_lo), round(erf_mid)),
 ("State: SETAs, NSF, Jobs Fund, PES", 20, 80),
 ("Investor finance to the building company", 80, 130),
]
lo = sum(b[1] for b in bridge); hi = sum(b[2] for b in bridge); mid = (lo + hi) / 2
p("BRIDGE")
for b in bridge: p(f"  {b[0]}: {b[1]} - {b[2]}")
p(f"  low sum: {' + '.join(str(b[1]) for b in bridge)} = {lo}")
p(f"  high sum: {' + '.join(str(b[2]) for b in bridge)} = {hi}")
p(f"  mid = {mid}")
for tgt in (1500, 1650, 1800):
    p(f"  target {tgt}: shortfall at low {tgt-lo}, mid {tgt-mid}, high {tgt-hi}")
# annuity check for investor finance
for rent in (0.10, 0.15):
    rev = boarders * board_fee
    pay = rev * rent
    i, n = 0.11, 20
    af = (1 - (1 + i) ** -n) / i
    p(f"investor finance: rent {int(rent*100)}% of R{r(rev)}m boarding fees = R{r(pay)}m/yr; annuity factor 11%/20y {round(af,3)}; debt capacity {r(pay*af)}")
# household debt
p(f"debt/household May 2026: {round(108357195/1896)} ; Oct 2025: {round(97783258/1896)} ; monthly rise {round((108357195-97783258)/7)} ; per household/month {round((108357195-97783258)/7/1896)}")
print("\n".join(out))
